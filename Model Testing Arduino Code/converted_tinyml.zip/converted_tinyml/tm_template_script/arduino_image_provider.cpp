/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  ==============================================================================*/

#include "image_provider.h"

/*
   The sample requires the following third-party libraries to be installed and
   configured:

   Arducam
   -------
   1. Download https://github.com/ArduCAM/Arduino and copy its `ArduCAM`
      subdirectory into `Arduino/libraries`. Commit #e216049 has been tested
      with this code.
   2. Edit `Arduino/libraries/ArduCAM/memorysaver.h` and ensure that
      "#define OV2640_MINI_2MP_PLUS" is not commented out. Ensure all other
      defines in the same section are commented out.

   JPEGDecoder
   -----------
   1. Install "JPEGDecoder" 1.8.0 from the Arduino library manager.
   2. Edit "Arduino/Libraries/JPEGDecoder/src/User_Config.h" and comment out
      "#define LOAD_SD_LIBRARY" and "#define LOAD_SDFAT_LIBRARY".
*/

#if defined(ARDUINO) && !defined(ARDUINO_ARDUINO_NANO33BLE)
#define ARDUINO_EXCLUDE_CODE
#endif  // defined(ARDUINO) && !defined(ARDUINO_ARDUINO_NANO33BLE)

#ifndef ARDUINO_EXCLUDE_CODE

#include <Arduino.h>
#include <Arduino_OV767X.h>

const int kCaptureWidth = 160;
const int kCaptureHeight = 120;
const int capDataLen = kCaptureWidth * kCaptureHeight * 2; // QQVGA: 160x120 X 2 bytes per pixel (YUV422)
byte captured_data[kCaptureWidth * kCaptureHeight * 2]; // QVGA: 320x240 X 2 bytes per pixel (RGB565)

// Crop image and convert it to grayscaleQ
TfLiteStatus ProcessImage(
  tflite::ErrorReporter* error_reporter,
  int image_width, int image_height,
  int8_t* image_data) {
 //  Serial.println("begging image process");
  //  const int skip_start_x = ceil((kCaptureWidth - image_width) / 2); // 40.5
  //  const int skip_start_y = ceil((kCaptureHeight - image_height) / 2); // 24
  //  const int skip_end_x_index = (kCaptureWidth - skip_start_x); // (176 - 40) = 135
  //  const int skip_end_y_index = (kCaptureHeight - skip_start_y); // 144 - 24 = 120
  const int imgSize = 96;

  for (int y = 0; y < imgSize; y++) {
    for (int x = 0; x < imgSize; x++) {
      int currentCapX = floor(map(x, 0, imgSize, 0, kCaptureWidth));
      int currentCapY = floor(map(y, 0, imgSize, 0, kCaptureHeight));

      int read_index = (currentCapY * kCaptureWidth + currentCapX) * 2;
      uint8_t Y1 = captured_data[read_index];
      uint8_t U = captured_data[read_index + 1];
      uint8_t Y2 = captured_data[read_index + 2];
      uint8_t V = captured_data[read_index + 3];

      // Convert YUV to RGB
      int r = Y1 + 1.402 * (V - 128);
      int g = Y1 - 0.344136 * (U - 128) - 0.714136 * (V - 128);
      int b = Y1 + 1.772 * (U - 128);

      r = min(max(r, 0), 255);
      g = min(max(g, 0), 255);
      b = min(max(b, 0), 255);

      // Convert RGB to grayscale
      float gray_value = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      int index = y * image_width + x;
      image_data[index] = static_cast<int8_t>(gray_value);
    }
  }
 
//  flushCap();
  //  Serial.println("processed image");
  //  Serial.println("processed image");
  return kTfLiteOk;
}
// Get an image from the camera module
TfLiteStatus GetImage(tflite::ErrorReporter* error_reporter, int image_width,
                      int image_height, int channels, int8_t* image_data) {
  static bool g_is_camera_initialized = false;
  if (!g_is_camera_initialized) {
   if (!Camera.begin(QQVGA, YUV422, 1)) {

      return kTfLiteError;
    }
    g_is_camera_initialized = true;
  }

    Camera.readFrame(captured_data);

  TfLiteStatus decode_status = ProcessImage(
                                 error_reporter, image_width, image_height, image_data);
  if (decode_status != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter, "DecodeAndProcessImage failed");
    return decode_status;
  }

  return kTfLiteOk;
}

#endif  // ARDUINO_EXCLUDE_CODE